import pandas as pd

def summarize(path):
    df = pd.read_csv(path)
    print(df.describe())
    return df
